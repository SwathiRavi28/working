const express = require('express');
var LocalStorage = require('node-localstorage').LocalStorage,
  localStorage = new LocalStorage('./scratch');
const router = express.Router();
router.get('/', (req, res) => res.render('welcome'));
router.get('/reset',(req, res) => res.render('reset'));
// Dashboard
router.get('/dashboard/:email', (req, res) => {
  //console.log('email id', req)
  if (typeof (req.params.email) !== "undefined") {
    // Store
    localStorage.setItem("email", req.params.email);
  } else {
    alert("Sorry, your browser does not support Web Storage...");
  }
 
  res.render('dashboard', {
    user: req.user
  })
}

);

module.exports = router;
