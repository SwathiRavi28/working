module.exports = {
  function (req, res, next) {
    return next();
    },
   
   function (req, res, next) {
   
      return next();
  },
  function (req, res, next) {
    
      return next();
    
  }
};
