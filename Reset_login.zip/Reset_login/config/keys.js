dbPassword = 'mongodb+srv://Swathi:' + encodeURIComponent('1u0MiNtS5NWXrUa4') + '@cluster0.ann9b.mongodb.net/<dbname>?retryWrites=true&w=majority';

module.exports = {
    mongoURI: dbPassword
};
