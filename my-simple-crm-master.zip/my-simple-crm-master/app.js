//  ========================================================Start of Header============================================================
const bodyParser = require("body-parser"),
methodOverride   = require("method-override"),
mongoose         = require("mongoose"),
express          = require("express"),
expressLayouts = require('express-ejs-layouts');
flash			 = require("connect-flash"),
app              = express();
const bcrypt = require('bcryptjs');
var sessionStorage = require('sessionstorage');
var passwordHash = require('password-hash');
const nodemailer = require('nodemailer');


// Authentication
const passport = require("passport"),
LocalStrategy  = require("passport-local");  

// Schemas
const Transaction = require ("./models/transaction"),
User 			  = require ("./models/user"),
Ticket 	  		  = require ("./models/ticket"),
Job 	   		  = require ("./models/job"),
Client 			  = require ("./models/client");

//tell express to serve public directory
app.use(express.static(__dirname + "/public"));
app.use(expressLayouts);
//tell express to look for ejs files
app.set("view engine", "ejs");

// use bodyParser
app.use(bodyParser.urlencoded({extended: true}));

// use methodOverride
app.use(methodOverride("_method"));

// mongoose.connect("mongodb://localhost/crm_app");

require('dotenv').config();

mongoose.connect(process.env.MongoDB, {
	//userNewUrlParser: true,
	useCreateIndex: true,
}).then (() => {
	console.log("Connected to the database");
}).catch(err => {
	console.log("Error", err.message);
});

// Optional. Use this if you create a lot of connections and don't want
// to copy/paste `{ useNewUrlParser: true }`.
//mongoose.set('useNewUrlParser', true);
mongoose.set('useUnifiedTopology', true);
mongoose.set('useFindAndModify', false);

// Mongoose Session
const session = require("express-session");
const MongoDBStore = require("connect-mongodb-session")(session);
const store = new MongoDBStore({
	uri: process.env.MongoDB,
	collection: 'mySessions'
});

// Catch errors
store.on('error', function(error) {
	console.log(error);
  });

// Use Express Session
app.use(session ({
	secret: "You my friend, I will defend, and if we change, well, I love you anyway",
	cookie: {
		maxAge: 1000 * 60 * 60 * 24 * 7 // 1 week
	},
	store: store,
	resave: true,
	saveUninitialized: true
}));

// Use Passport
app.use(passport.initialize());
app.use(passport.session());

passport.use(new LocalStrategy(User.authenticate()));
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());

// Use Flash
app.use(flash());

// Use Current Logged in Information and Flashing Information
app.use(function(req, res, next){
	res.locals.currentUser = req.user;
	res.locals.error = req.flash("error");
	res.locals.success = req.flash("success");
	res.locals.info = req.flash("info");
	next();
});

// Functions
//let isLoggedIn = require("./functions/isLoggedIn");

//  ========================================================End of Header==============================================================

// Routes
const users  = require("./routes/users"),
tickets 	 = require("./routes/tickets"),
clients 	 = require("./routes/clients"),
jobs 		 = require("./routes/jobs"),
transactions = require("./routes/transactions");
dashboard 	 = require("./routes/dashboard");

app.use("/users", users);
app.use("/tickets", tickets);
app.use("/clients", clients);
app.use("/jobs", jobs);
app.use("/transactions", transactions);
app.use(dashboard);

// =======================Login/Register

app.get("/login", function(req, res){
	res.render("login");
});
app.get("/register", function(req, res){
	res.render("register");
});
app.get("/reset", function(req, res){
	res.render("reset");
});
app.get("/resethome", function(req, res){
	res.render("resethome");
});

app.get("/welcome", function(req, res){
	res.render("welcome");
});
 
app.post("/loginpage", async (req,res)=>{
	console.log(req.body);
	const  { email_address,password } = req.body
	try {
		const user = await User.findOne({ email_address:email_address })
		if (user != null) {
			var hash = passwordHash.generate(password);
			if(hash==user.password)
			{
				alert("success")
				res.redirect('/dashboard');
			}
		}
		else {
			console.log( 'user doesnt exists')
		  errors.push({ msg: 'user doesnt exists' });
		  res.render('login', {
			email_address,
		  });
		}
	  }
	  catch (err) {
		console.log(err)
	  }
});

// =======================Logout
app.get("/logout", function(req, res){
	req.logout();
	req.flash("success", "Logged Out");
	res.redirect("/login");
});

// =======================Error

// app.get("*", isLoggedIn, function(req, res){ 
// 	res.render("not_found");
// });

app.post('/reset', async (req, res) => {
	console.log('i am in');
	var { email_address } = req.body;
	var hash;
	mailOptions.to = email_address;
	let errors = [];
  
	if (!email_address) {
	  errors.push({ msg: 'Please enter all fields' });
	}
  
  
	if (errors.length > 0) {
	  res.render('reset', {
		errors,
		email_address,
	  });
	} else {
  
	  try {
		const user = await User.findOne({ email_address: email_address })
		if (user != null) {
		  hash = user.password;
		}
		else {
		  errors.push({ msg: 'email_address doesnt exists' });
		  res.render('reset', {
			errors,
			email_address,
		  });
		}
	  }
	  catch (err) {
		console.log(err)
	  }
  
	  let samplemail_address = '<p>Hi, </p>'
		+ '<p>Please click on below link to reset password</p>'
		+ `<a target='blank' href="http://localhost:5000/users/resethome/${hash}/${email_address}" >Reset your password</a>`
		+ '<p>Regards</p>'
	  mailOptions.html = samplemail_address;
	  console.log('hashed password', hash)
	  // var email_address = localStorage.getItem("email_address");
	  console.log('email_address in reset', email_address);
	  await transporter.sendMail(mailOptions)
	  res.status(200).json({
		message: "Verification mail sent"
	  });
  
	}
  });
  
  app.get('/resethome/:pwd/:email_address', (req, res) => {
	sessionStorage.setItem('email_address', req.params.email_address);
	console.log('email_address stored', sessionStorage.getItem('email_address'));
	res.render('resethome')
  })
  
  app.post('/resethome', (req, res) => {
	console.log('i am in now');
	var email_address = sessionStorage.getItem('email_address')
	const { password1, password2 } = req.body;
	let errors = [];
  
	if (!password1 || !password2) {
	  errors.push({ msg: 'Please enter all fields' });
	}
  
	if (password1 != password2) {
	  errors.push({ msg: 'Passwords do not match' });
	}
  
	if (password2.length < 6) {
	  errors.push({ msg: 'Password must be at least 6 characters' });
	}
  
	if (errors.length > 0) {
	  res.render('reset', {
		errors,
		email_address,
		password1,
		password2
	  });
	} else {
  
	  var hash = passwordHash.generate(password1);
	  console.log('hashed password', hash)
	  // var email_address = localStorage.getItem("email_address");
	  console.log('email_address in reset', email_address)
	  User.findOneAndUpdate({ email_address:email_address },
		{ password: hash }, null, function (err, docs) {
		  if (err) {
			console.log(err)
		  }
		  else {
			//console.log("Original Doc : ", docs);
			req.flash(
			  'success_msg',
			  'Password reset successfull'
			);
			res.redirect('/login');
		  }
		}).then(res => console.log('success'))
		.catch(err => console.log(err))
	}
  });


  app.post('/register', (req, res) => {
	const { first_name, email_address, password, password2 } = req.body;
	console.log(req.body)
	let errors = [];
  
	if (!first_name || !email_address || !password || !password2) {
	  errors.push({ msg: 'Please enter all fields' });
	}
  
	if (password != password2) {
	  errors.push({ msg: 'Passwords do not match' });
	}
  
	if (password.length < 6) {
	  errors.push({ msg: 'Password must be at least 6 characters' });
	}
  console.log('errors',errors)
	if (errors.length > 0) {
	  res.render('register', {
		errors,
		first_name,
		email_address,
		password,
		password2
	  });
	} else {
	  User.findOne({ email_address: email_address }).then(user => {
		if (user) {
		  errors.push({ msg: 'email_address already exists' });
		  res.render('register', {
			errors,
			first_name,
			email_address,
			password,
			password2
		  });
		} else {
		  const newUser = new User({
			first_name,
			email_address,
			password
		  });
  
		  var hashedPassword = passwordHash.generate(password);
		  newUser.password = hashedPassword;
		  newUser
			.save()
			.then(user => {
			  req.flash(
				'success_msg',
				'You are now registered and can log in'
			  );
			  res.redirect('/login');
			})
			.catch(err => console.log(err));
		}
	  });
	}
  });
	

// =======================Server

app.listen(process.env.PORT || 5000, function() { 
  console.log('Server listening on port'); 
});
