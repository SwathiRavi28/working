$(document).ready(function() {
    $('.dropdown_search').select2();
});