$(document).ready( function () {
    $('#myHistoryTable').DataTable();
} );