// Confirm Logged In User

function isLoggedIn(req, res, next){
	console.log("login:yes")
	if(req.isAuthenticated()){
		return next();
	} 
	req.flash("error", "Please Login");
	res.redirect("/welcome");
}

module.exports = isLoggedIn;